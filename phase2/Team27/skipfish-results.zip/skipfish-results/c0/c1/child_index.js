var child = [
  { 'dupe': false, 'type': 4, 'name': 'css', 'dir': 'c0', 'linked': 2, 'url': 'http://localhost:8080/font-awesome/css/', 'fetched': true, 'code': 404, 'len': 292, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'iso-8859-1', 'missing': true, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x5ad3b58c }
];
