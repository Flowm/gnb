<?php

function checkPasswordStrength($pass) {
    if (strlen($pass) < 8 || strlen($pass) > 20) {
        return false;
    }

    if (!preg_match("#[0-9]+#",$pass)) {
        return false;
    }
    if (!preg_match("#[a-zA-Z]+#", $pass)) {
        return false;
    }
    return true;
}

$test = checkPasswordStrength("helloworld");
$test = checkPasswordStrength("11111111");
$test = checkPasswordStrength("1qazxsw23edc");

echo "Hello";

?>
