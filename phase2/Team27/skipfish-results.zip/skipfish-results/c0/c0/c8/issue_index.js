var issue = [
  { 'severity': 0, 'type': 10803, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 3749, 'decl_mime': 'text/css', 'sniff_mime': 'text/css', 'cset': '[none]', 'dir': 'i0' }
];
