<?php

function toBase10($base64Str) {
    $alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

    $result = 0;
    foreach(str_split($base64Str) as $letter) {
        $result = ($result*64) + strpos($alphabet,$letter);
    }
    return $result;
}

$pin = "123456";
$amount = "100";
$iban = "10000001";

$tan = "TBOLyjeyB+x/csJ";
$salt = substr($tan,-5);

$timestamp = toBase10($salt);

$data = $pin . $iban . $amount . $salt;
$hash = hash('sha256',$data, true);

$result = base64_encode($hash);

$result = substr($result,0,10) . $salt;


echo $result;