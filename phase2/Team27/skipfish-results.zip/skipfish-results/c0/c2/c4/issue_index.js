var issue = [
  { 'severity': 0, 'type': 10901, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 18028, 'decl_mime': '[none]', 'sniff_mime': 'application/binary', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 0, 'type': 10801, 'sid': '0', 'extra': 'application/binary', 'fetched': true, 'code': 200, 'len': 18028, 'decl_mime': '[none]', 'sniff_mime': 'application/binary', 'cset': '[none]', 'dir': 'i1' }
];
