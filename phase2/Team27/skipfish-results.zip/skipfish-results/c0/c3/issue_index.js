var issue = [
  { 'severity': 0, 'type': 10204, 'sid': '0', 'extra': 'X-Powered-By', 'fetched': true, 'code': 403, 'len': 285, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'iso-8859-1', 'dir': 'i0' },
  { 'severity': 0, 'type': 10204, 'sid': '0', 'extra': 'X-Pad', 'fetched': true, 'code': 403, 'len': 285, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'iso-8859-1', 'dir': 'i1' }
];
