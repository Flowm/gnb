var issue = [
  { 'severity': 0, 'type': 10803, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 47721, 'decl_mime': 'text/css', 'sniff_mime': 'application/javascript', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 0, 'type': 10801, 'sid': '0', 'extra': 'application/javascript', 'fetched': true, 'code': 200, 'len': 47721, 'decl_mime': 'text/css', 'sniff_mime': 'application/javascript', 'cset': '[none]', 'dir': 'i1' }
];
