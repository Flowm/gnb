var issue = [
  { 'severity': 0, 'type': 10801, 'sid': '0', 'extra': 'application/binary', 'fetched': true, 'code': 200, 'len': 45404, 'decl_mime': '[none]', 'sniff_mime': 'application/binary', 'cset': '[none]', 'dir': 'i0' }
];
